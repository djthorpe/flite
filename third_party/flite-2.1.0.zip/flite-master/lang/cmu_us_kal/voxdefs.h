#define VOXNAME cmu_us_kal
#define REGISTER_VOX register_cmu_us_kal
#define UNREGISTER_VOX unregister_cmu_us_kal
#define VOXHUMAN "kal"
#define VOXGENDER "unknown"
#define VOXVERSION 1.0
