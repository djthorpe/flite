#define VOXNAME cmu_us_slt
#define REGISTER_VOX register_cmu_us_slt
#define UNREGISTER_VOX unregister_cmu_us_slt
#define VOXHUMAN "slt"
#define VOXGENDER "unknown"
#define VOXVERSION 1.0
